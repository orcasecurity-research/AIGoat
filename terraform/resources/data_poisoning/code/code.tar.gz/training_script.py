import pandas as pd
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity
import boto3
from io import StringIO
import pickle
import tarfile
import argparse

# Initialize a session using Amazon S3


def parse_args():
    parser = argparse.ArgumentParser()

    # Add hyperparameters
    parser.add_argument('--bucket_name', type=str, required=True)  # Default value for local testing

    return parser.parse_args()
args = parse_args()

s3 = boto3.client('s3')

# Access the bucket name from hyperparameters
bucket_name = args.bucket_name

obj = s3.get_object(Bucket= bucket_name, Key= "product_ratings.csv") 


# Load the dataset
file_content = obj['Body'].read().decode('utf-8')
df = pd.read_csv(StringIO(file_content))


# Creating a user-item matrix
ui_matrix = df.pivot_table(index='userId', columns='productId', values='rating', fill_value=0)

# Apply Truncated SVD
svd = TruncatedSVD(n_components=5, random_state=42)
matrix_reduced = svd.fit_transform(ui_matrix)

# Calculate the cosine similarity
cosine_sim = cosine_similarity(matrix_reduced)

# Assuming `svd` and `cosine_sim` have been defined and trained as in your notebook
# Save the models and matrices
with open('model.pkl', 'wb') as f:
    pickle.dump(svd, f)

with open('cosine_sim.pkl', 'wb') as f:
    pickle.dump(cosine_sim, f)

with open('ui_matrix.pkl', 'wb') as f:
    pickle.dump(ui_matrix, f)
    
# Create a tar.gz file
with tarfile.open('model.tar.gz', 'w:gz') as tar:
    tar.add('ui_matrix.pkl')
    tar.add('cosine_sim.pkl')
    tar.add('model.pkl')


# Upload the model file to S3
s3.upload_file('model.tar.gz', bucket_name, 'model.tar.gz')



